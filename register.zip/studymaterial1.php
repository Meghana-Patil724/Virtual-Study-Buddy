<!DOCTYPE html>
<html>
<head>
  
<link rel="stylesheet" href="sem1.css">
</head>
<body>
<section id="header">
<a href="#"><img src="b.png" class="logo"/></a>
<div>
<ul id="project">
<li><a href="sem1.html">Home</a></li>
<li><a href="quiz1.html">Quizez</a></li>
<li><a href="progress1.html">Progress</a></li>
<li><a class="active" href="studymaterial1.html">Study Material</a></li>
</section>

<section id="header-1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</section>
    <section id="study" class="campus-col">
        <h1>Study Material</h1>
        <p>Access the study material and enjoy learning</p>
        <div class="campus-col">
            <h3><a href="file:///C:/xampp/htdocs/Project2/dsa.pdf">Data Structure</a></h3>
        </div>
    </div>
    <div class="campus-col">
          <h3><a href="file:///C:/xampp/htdocs/Project2/dbms1.pdf">DBMS</a></h3>
    </div>
    <div class="campus-col">
    <h3><a href="file:///C:/xampp/htdocs/Project2/python.pdf">Python</a></h3>
    <h3><a href="https://www.programiz.com/python-programming/online-compiler/">Python Compiler</a></h3>
    </div>
    <div class="campus-col">
         <h3><a href="file:///C:/xampp/htdocs/Project2/system1.pdf">System Fundamentals</a></h3>
    </div>
    </section>
    
        
        
</section>
</head>
<body>
<script>
// Get the modal
var modal = document.getElementById('id01');
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
</section>

</body>

</html>